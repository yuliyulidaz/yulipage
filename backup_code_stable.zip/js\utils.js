// Expose React hooks globally
window.useState = React.useState;
window.useEffect = React.useEffect;
window.useRef = React.useRef;
window.useCallback = React.useCallback;
window.useLayoutEffect = React.useLayoutEffect;

(function () {
    const { useState, useEffect } = React;

    // ----------------------------------------------------------------------
    // 1. Utils & Helpers
    // ----------------------------------------------------------------------

    window.isMobile = function () {
        return /Android|webOS|BlackBerry|IEMobile|Opera Mini|iPad|iPhone|iPod/.test(navigator.userAgent);
    };

    window.isIOS = function () {
        return /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    };

    // Haptic Feedback Helper
    window.haptic = {
        tap: () => {
            if (navigator.vibrate) navigator.vibrate(10);
        },
        success: () => {
            if (navigator.vibrate) navigator.vibrate([30, 50, 30]);
        },
        error: () => {
            if (navigator.vibrate) navigator.vibrate([50, 100, 50]);
        }
    };

    window.ensureFontsLoaded = async function () {
        try { await document.fonts.ready; } catch (e) { console.warn('폰트 API 확인 실패', e); }
    };

    window.fontCache = new Map();
    window.BOTTOM_BUFFER_P1 = 220; // Title area buffer

    window.PAPER_SIZES = {
        'A6': { label: 'A6 (105x148mm)', width: '105mm', height: '148mm', contentHeight: 460, className: 'size-a6' },
        'A5': { label: 'A5 (148x210mm)', width: '148mm', height: '210mm', contentHeight: 640, className: 'size-a5' },
        'B5': { label: 'B5 (182x257mm)', width: '182mm', height: '257mm', contentHeight: 800, className: 'size-b5' }
    };

    window.FONT_MAP = {
        'noto': { name: '본문 명조', family: "'Noto Serif KR', serif", url: 'https://fonts.googleapis.com/css2?family=Noto+Serif+KR:wght@200;300;400;500&display=swap' },
        'nanum': { name: '나눔 명조', family: "'Nanum Myeongjo', serif", url: 'https://fonts.googleapis.com/css2?family=Nanum+Myeongjo:wght@400;700;800&display=swap' },
        'hahmlet': { name: '함렛', family: "'Hahmlet', serif", url: 'https://fonts.googleapis.com/css2?family=Hahmlet:wght@100;200;300;400;500;600&display=swap' },
        'gowun': { name: '고운 바탕', family: "'Gowun Batang', serif", url: 'https://fonts.googleapis.com/css2?family=Gowun+Batang:wght@400;700&display=swap' },
        'ridi': { name: '리디바탕', family: "'Ridibatang', serif", url: 'https://webfontworld.github.io/ridibatang/Ridibatang.css' },
        'kyobo': { name: '교보 손글씨', family: "'KyoboHandwriting2019', serif", url: 'https://cdn.jsdelivr.net/gh/projectnoonnu/noonfonts_2001@1.1/KyoboHandwriting2019.woff' },
        'maru': { name: '마루 부리', family: "'MaruBuri', serif", url: 'https://hangeul.pstatic.net/hangeul_static/css/maru-buri.css' }
    };

    window.escapeFontName = function (fontUrl) {
        return fontUrl;
    };

    window.prepareFontEmbedCSS = async function (activeFontKey) {
        if (window.fontCache.has(activeFontKey)) return window.fontCache.get(activeFontKey);
        try {
            const fontInfo = window.FONT_MAP[activeFontKey];
            if (!fontInfo) return null;
            // For WOFF fonts (Kyobo), we might need direct base64 embedding which is tricky from client-side CDN fetch due to CORS often.
            // Simplified logic: Try fetch, if fail, assume user has it or it won't embed.
            // Ideally for Ridibatang CSS, we parse it.
            const cssRes = await fetch(fontInfo.url);
            let cssText = await cssRes.text();

            // Basic CSS parsing for font-face url()
            const urlRegex = /url\(([^)]+)\)/g;
            let match;
            const replacements = [];
            while ((match = urlRegex.exec(cssText)) !== null) {
                let fullUrl = match[1].replace(/['"]/g, '');
                // Handle relative URLs if needed, though most CDN CSS use absolute.
                replacements.push({ original: match[0], url: fullUrl });
            }
            await Promise.all(replacements.map(async (item) => {
                try {
                    const fontRes = await fetch(item.url);
                    const fontBlob = await fontRes.blob();
                    return new Promise((resolve, reject) => {
                        const reader = new FileReader();
                        reader.onloadend = () => {
                            cssText = cssText.replace(item.url, reader.result);
                            resolve();
                        };
                        reader.onerror = reject;
                        reader.readAsDataURL(fontBlob);
                    });
                } catch (e) { }
            }));
            window.fontCache.set(activeFontKey, cssText);
            return cssText;
        } catch (e) { return null; }
    };

    window.useDebounce = function (value, delay) {
        const [debouncedValue, setDebouncedValue] = useState(value);
        useEffect(() => {
            const handler = setTimeout(() => { setDebouncedValue(value); }, delay);
            return () => clearTimeout(handler);
        }, [value, delay]);
        return debouncedValue;
    };

    window.captureNode = async function (node, fileName, width, height, fontEmbedCSS = null) {
        await window.ensureFontsLoaded();

        const options = {
            quality: 1.0, pixelRatio: 3, cacheBust: false,
            width: width, height: height,
            style: { transform: 'none', margin: '0' },
            filter: (node) => {
                return !node.classList || !node.classList.contains('no-capture');
            }
        };

        if (fontEmbedCSS) {
            options.fontEmbedCSS = fontEmbedCSS;
        }

        if (window.isMobile()) {
            try { await htmlToImage.toBlob(node, options); } catch (e) { }
            await new Promise(r => setTimeout(r, 200));
        }

        const blob = await htmlToImage.toBlob(node, options);
        if (!blob) throw new Error('Blob creation failed');

        if (window.isIOS() && navigator.share && navigator.canShare) {
            const file = new File([blob], fileName, { type: 'image/png' });
            if (navigator.canShare({ files: [file] })) {
                await navigator.share({ files: [file], title: fileName });
                return;
            }
        }

        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.download = fileName;
        link.href = url;
        link.style.display = 'none'; // Ensure hidden
        document.body.appendChild(link);
        link.click();

        // Critical for Android: Delay removal
        setTimeout(() => {
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
        }, 1000);
    };

    window.getBlobFromNode = async function (node, width, height, fontEmbedCSS = null) {
        await window.ensureFontsLoaded();

        const options = {
            quality: 1.0, pixelRatio: 3, cacheBust: false,
            width: width, height: height,
            style: { transform: 'none', margin: '0' },
            filter: (node) => {
                return !node.classList || !node.classList.contains('no-capture');
            }
        };

        if (fontEmbedCSS) {
            options.fontEmbedCSS = fontEmbedCSS;
        }

        if (window.isMobile()) {
            // Mobile stabilization
            try { await htmlToImage.toBlob(node, options); } catch (e) { }
            await new Promise(r => setTimeout(r, 200));
        }

        return await htmlToImage.toBlob(node, options);
    };

    // window.PAGE_CONTENT_HEIGHT is now dynamic based on PAPER_SIZES
    window.BOTTOM_BUFFER_P1 = 15;
    window.STORAGE_KEY = 'novel_generator_draft';
})();
