(function () {
    /**
     * Calculates pages based on text, font, and measurement container.
     * @param {string} text - The input text.
     * @param {string} fontKey - The key of the active font.
     * @param {HTMLElement} measureBox - The hidden DOM element used for measurement.
     * @param {object} metadata - Metadata containing title, etc.
     * @param {string} pageSize - The selected paper size key (e.g., 'A6', 'A5').
     * @returns {Array} Array of page objects.
     */
    window.calculatePages = function (text, fontKey, measureBox, metadata, pageSize = 'A6') {
        if (!measureBox) return [];

        const sizeConfig = window.PAPER_SIZES[pageSize] || window.PAPER_SIZES['A6'];

        // 1. Ensure measurement box matches the target page's geometry and font exactly
        // We MUST include 'page-container' so it picks up the padding from style.css
        measureBox.className = `hidden-measure page-container ${sizeConfig.className}`;

        // Critical Fix: Inline dimensions to ensure measurement works even if CSS fails
        measureBox.style.width = sizeConfig.width;
        measureBox.style.padding = (pageSize === 'A6') ? '20px 25px' :
            (pageSize === 'B5') ? '25px 40px' :
                (pageSize === 'A5') ? '25px 35px' : '20px 25px';
        measureBox.style.boxSizing = 'border-box'; // Ensure padding is handled correctly

        // Critical Safety: Forcefully hide and remove from pointer events
        measureBox.style.position = 'absolute';
        measureBox.style.top = '-9999px';
        measureBox.style.left = '-9999px';
        measureBox.style.zIndex = '-9999';
        measureBox.style.visibility = 'hidden';
        measureBox.style.pointerEvents = 'none';

        // Safety: Check if font exists
        const fontConfig = window.FONT_MAP[fontKey] || window.FONT_MAP['noto'] || { family: 'serif' };
        measureBox.style.fontFamily = fontConfig.family;
        measureBox.style.fontSize = '12px';
        measureBox.style.fontWeight = '300';
        measureBox.style.lineHeight = '1.8';
        measureBox.style.letterSpacing = '-0.02em';
        measureBox.style.wordBreak = 'normal';
        measureBox.style.overflowWrap = 'anywhere';
        const rawParagraphs = text.split('\n');
        let currentParagraphs = [];
        let pageNum = 1;
        let resultPages = [];

        let queue = rawParagraphs.map(text => {
            const trimmed = text.trim();
            if (trimmed === '***') return { text: '*\u00A0\u00A0\u00A0\u00A0\u00A0*\u00A0\u00A0\u00A0\u00A0\u00A0*', isContinued: false, isSceneBreak: true };
            return { text: text, isContinued: false, isSceneBreak: false };
        });

        measureBox.innerHTML = '';

        // Title placeholder for page 1
        if (metadata.title && pageNum === 1) {
            const titlePlaceholder = document.createElement('div');
            titlePlaceholder.style.height = "200px";
            titlePlaceholder.style.width = "100%";
            titlePlaceholder.style.marginBottom = "0";
            measureBox.appendChild(titlePlaceholder);
        }

        const findSplitIndex = (text, maxHeight, isContinued) => {
            const tempP = document.createElement('p');
            tempP.style.lineHeight = "1.8";
            tempP.style.marginBottom = "0";
            tempP.style.fontFamily = window.FONT_MAP[fontKey].family;

            if (isContinued) tempP.classList.add('continued');
            else tempP.style.textIndent = '1em';

            measureBox.appendChild(tempP);

            let low = 0;
            let high = text.length;
            let bestIdx = 0;

            while (low <= high) {
                const mid = Math.floor((low + high) / 2);
                const subText = text.substring(0, mid);
                tempP.textContent = subText;
                if (tempP.offsetHeight <= maxHeight) {
                    bestIdx = mid;
                    low = mid + 1;
                } else {
                    high = mid - 1;
                }
            }
            measureBox.removeChild(tempP);
            return bestIdx;
        };

        let safetyCounter = 0;
        const MAX_ITERATIONS = 5000;

        while (queue.length > 0) {
            safetyCounter++;
            if (safetyCounter > MAX_ITERATIONS) {
                console.error("Infinite loop detected in calculatePages. Breaking.");
                // Push whatever is left as a final page to avoid data loss
                if (currentParagraphs.length > 0) resultPages.push({ paragraphs: currentParagraphs });
                break;
            }

            const item = queue.shift();
            const effectiveText = (!item.isSceneBreak && item.text.trim().length === 0) ? '\u00A0' : item.text;

            const p = document.createElement('p');
            p.textContent = effectiveText;
            p.style.lineHeight = "1.8";
            p.style.marginBottom = "0";
            p.style.fontFamily = window.FONT_MAP[fontKey].family;

            if (item.isSceneBreak) {
                p.style.textAlign = 'center';
                p.style.textIndent = '0';
            } else if (item.isContinued) {
                p.classList.add('continued');
            } else {
                p.style.textIndent = '1em';
            }

            measureBox.appendChild(p);

            const currentHeight = measureBox.scrollHeight;
            const currentBuffer = (pageNum === 1) ? window.BOTTOM_BUFFER_P1 : 0;

            // Dynamic Size Logic
            const sizeConfig = window.PAPER_SIZES[pageSize] || window.PAPER_SIZES['A6'];
            const limitHeight = sizeConfig.contentHeight - currentBuffer;

            if (currentHeight <= limitHeight) {
                currentParagraphs.push({ text: effectiveText, isContinued: item.isContinued, isSceneBreak: item.isSceneBreak });
            } else {
                measureBox.removeChild(p);
                const currentBaseHeight = measureBox.scrollHeight;
                const availableHeight = limitHeight - currentBaseHeight;

                // Safety: If available height is too small, start new page
                // SPECIAL CASE: If this is the FIRST item on the page and it doesn't fit,
                // we must force it in or split it, otherwise we get infinite empty pages.
                if (currentParagraphs.length === 0) {
                    // Force split if possible, otherwise force push locally
                    const splitIdx = findSplitIndex(effectiveText, limitHeight, item.isContinued);
                    if (splitIdx > 0) {
                        const partA = effectiveText.substring(0, splitIdx);
                        const partB = effectiveText.substring(splitIdx);
                        currentParagraphs.push({ text: partA, isContinued: item.isContinued, isSceneBreak: item.isSceneBreak });
                        if (partB.length > 0) queue.unshift({ text: partB, isContinued: true, isSceneBreak: item.isSceneBreak });
                    } else {
                        // It just doesn't fit at all (e.g. huge single word or image?). Force push it to avoid infinite loop.
                        // Warn about overflow but proceed.
                        currentParagraphs.push({ text: effectiveText, isContinued: item.isContinued, isSceneBreak: item.isSceneBreak });
                    }
                    // After forcing content, we break the page (because we overflowed)
                    resultPages.push({ paragraphs: currentParagraphs });
                    currentParagraphs = [];
                    pageNum++;
                    measureBox.innerHTML = '';
                    continue;
                }

                if (availableHeight < 18) {
                    queue.unshift(item);
                    resultPages.push({ paragraphs: currentParagraphs });
                    currentParagraphs = [];
                    pageNum++;
                    measureBox.innerHTML = '';
                    continue;
                } else {
                    const splitIdx = findSplitIndex(effectiveText, availableHeight, item.isContinued);

                    if (splitIdx > 0) {
                        const partA = effectiveText.substring(0, splitIdx);
                        const partB = effectiveText.substring(splitIdx);

                        currentParagraphs.push({ text: partA, isContinued: item.isContinued, isSceneBreak: item.isSceneBreak });

                        if (partB.length > 0) {
                            queue.unshift({ text: partB, isContinued: true, isSceneBreak: item.isSceneBreak });
                        }
                    } else {
                        queue.unshift(item);
                        resultPages.push({ paragraphs: currentParagraphs });
                        currentParagraphs = [];
                        pageNum++;
                        measureBox.innerHTML = '';
                        continue;
                    }
                }

                // Fallback (redundant)
                resultPages.push({ paragraphs: currentParagraphs });
                currentParagraphs = [];
                pageNum++;
                measureBox.innerHTML = '';
            }
        }

        if (currentParagraphs.length > 0) resultPages.push({ paragraphs: currentParagraphs });

        return resultPages;
    };

    window.renderPageContent = function (page, fontKey) {
        if (!page || !page.paragraphs) return '';
        const fontFamily = window.FONT_MAP[fontKey] ? window.FONT_MAP[fontKey].family : 'serif';

        return page.paragraphs.map(p => {
            let style = `line-height: 1.8 !important; margin-bottom: 0px; font-family: ${fontFamily};`;
            let className = '';

            if (p.isSceneBreak) {
                style += 'text-align: center; text-indent: 0;';
            } else if (p.isContinued) {
                className = 'continued';
            } else {
                style += 'text-indent: 1em;';
            }

            // Build P tag
            // Note: We include styling inline to ensure it persists in html-to-image or downloads if external css fails,
            // but classes are also used for interactive styling logic (like highlighting).
            if (className) {
                return `<p class="${className}" style="${style}">${p.text}</p>`;
            } else {
                return `<p style="${style}">${p.text}</p>`;
            }
        }).join('');
    };
})();
